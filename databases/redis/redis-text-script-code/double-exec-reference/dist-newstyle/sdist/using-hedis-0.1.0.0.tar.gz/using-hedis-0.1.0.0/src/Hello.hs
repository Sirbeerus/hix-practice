{-# LANGUAGE OverloadedStrings #-}

module Hello where

import Database.Redis
import qualified Data.ByteString as B
import Control.Monad
import Control.Monad.IO.Class
import Data.Maybe
import System.IO 

bytes :: B.ByteString
bytes = Hello, World :: B.ByteString
 
main :: IO (Either Reply B.ByteString)
main = do
conn <- connect defaultConnectInfo
runRedis conn $ echo bytes
